from django.shortcuts import render

# Create your views here.
def index(request):
   return render(request, 'index.html')

def electronica(request):
   data = {
     'titulo': 'Electronica',
     'producto1': 'Mac',
     'producto2': 'Iphone',
     'producto3': 'Play',
  }
   return render(request, 'productos.html', data)

def juguetes(request):
   data = {
     'titulo': 'Juguetes',
     'producto1': 'Auto',
     'producto2': 'Pelota de Futbol',
     'producto3': 'MaxSteel',
  }
   return render(request, 'productos.html', data)

def ropa(request):
   data = {
     'titulo': 'Ropa',
     'producto1': 'Pantalones',
     'producto2': 'Chaqueta',
     'producto3': 'Camisa',
  }
   return render(request, 'productos.html', data)